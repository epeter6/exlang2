export class AuthenticationResponse {
    token?: string;
    success: boolean;
    errors?: string[];
}
