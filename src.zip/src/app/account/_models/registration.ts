export class Registration {
    name: string;
    email: string;
    password: string;
    confirmPassword: string
}
