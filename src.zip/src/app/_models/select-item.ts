export class SelectItem {
    name: string;
    code: string;
}
