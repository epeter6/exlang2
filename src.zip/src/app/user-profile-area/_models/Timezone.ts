export class Timezone {
    value: string;
    abbr: string;
    offset: number;
    isdst: boolean;
    text: string;
}
