export class SessionSetting {
    sessionDuration: number | null;
    peopleBook: string;
    timeZone: string;
    email: string | null;

}
